
import React, { useState, useCallback } from 'react';
import { SlideData, ContentElement, TableElement, CardGridElement, GanttChartElement, HeadingElement, HighlightBoxElement, ListElement, ParagraphElement } from '../types';

// --- ICONS ---
const EditIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5"} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>
);
const SaveIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5"} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" /></svg>
);
const CancelIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5"} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
);

// --- EDITABLE COMPONENTS ---

interface EditableProps<T> {
    value: T;
    onChange: (value: T) => void;
    isEditing: boolean;
    renderView: (value: T) => React.ReactNode;
    renderEdit: (value: T, onChange: (value: T) => void) => React.ReactNode;
}

const Editable = <T,>({ value, onChange, isEditing, renderView, renderEdit }: EditableProps<T>) => {
    return isEditing ? renderEdit(value, onChange) : renderView(value);
};

const EditableTextArea: React.FC<{value: string; onChange: (newValue: string) => void; className?: string;}> = ({value, onChange, className}) => {
    const [localValue, setLocalValue] = useState(value);
    const handleBlur = () => onChange(localValue);
    return <textarea value={localValue} onChange={(e) => setLocalValue(e.target.value)} onBlur={handleBlur} className={className || "w-full p-2 border border-blue-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:outline-none transition"} rows={value.split('\n').length + 1} />;
}

const EditableTable: React.FC<{value: TableElement; onChange: (value: TableElement) => void; isEditing: boolean}> = ({ value, onChange, isEditing }) => {
    const handleCellChange = (rowIndex: number, colIndex: number, newText: string) => {
        const newRows = [...value.rows];
        newRows[rowIndex][colIndex] = newText;
        onChange({ ...value, rows: newRows });
    };

    return (
        <div className="overflow-x-auto">
            <table className="w-full border-collapse mt-6 text-sm shadow-lg rounded-lg overflow-hidden">
                <thead className="bg-gradient-to-r from-blue-800 to-blue-500 text-white text-right font-semibold">
                    <tr>{value.headers.map((h, i) => <th key={i} className="p-4 border border-slate-300" dangerouslySetInnerHTML={{ __html: h }} />)}</tr>
                </thead>
                <tbody>
                    {value.rows.map((row, rIndex) => (
                        <tr key={rIndex} className="even:bg-slate-50 hover:bg-sky-100 transition-colors duration-200">
                            {row.map((cell, cIndex) => (
                                <td key={cIndex} className="p-1 sm:p-2 border border-slate-200 align-top">
                                    {isEditing ? (
                                        <EditableTextArea value={cell} onChange={(newVal) => handleCellChange(rIndex, cIndex, newVal)} className="w-full bg-inherit text-sm"/>
                                    ) : (
                                        <div className="p-2 min-h-[40px]" dangerouslySetInnerHTML={{ __html: cell }} />
                                    )}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

// --- VIEW COMPONENTS ---

const Heading: React.FC<{ element: HeadingElement }> = ({ element }) => {
    const commonClasses = "text-slate-800 border-b-2 pb-3 mb-6";
    const Tag = `h${element.level}` as keyof React.ReactHTML;
    const sizeClasses = {
        2: `text-3xl border-b-4 border-blue-500 pb-4`,
        3: `text-2xl border-blue-400`,
        4: `text-xl border-blue-300/70`,
    };
    return (
        <div>
            <Tag className={`${commonClasses} ${sizeClasses[element.level]}`} dangerouslySetInnerHTML={{ __html: element.text }} />
            {element.subtext && <p className="text-slate-500 -mt-4 mb-6" dangerouslySetInnerHTML={{ __html: element.subtext }} />}
        </div>
    );
};

const HighlightBox: React.FC<{ element: HighlightBoxElement }> = ({ element }) => {
    const variants = {
        goal: 'from-blue-100 to-blue-200 border-blue-500',
        vision: 'from-blue-50 to-sky-100 border-blue-500',
        decision: 'from-purple-50 to-violet-100 border-purple-500 text-slate-800',
        principles: 'from-slate-50 to-slate-100 border-slate-400',
        success: 'from-green-50 to-emerald-100 border-green-500 text-green-900',
        info: 'from-sky-50 to-cyan-100 border-sky-500 text-sky-900',
        warning: 'from-red-50 to-rose-100 border-red-500 text-red-900'
    };
    return <div className={`my-5 p-6 bg-gradient-to-br rounded-xl border-r-8 shadow-md ${variants[element.variant]}`} dangerouslySetInnerHTML={{ __html: element.text }} />;
};

const Paragraph: React.FC<{ element: ParagraphElement }> = ({ element }) => <p className="text-slate-700 leading-relaxed mb-4" dangerouslySetInnerHTML={{ __html: element.text }} />;

const List: React.FC<{ element: ListElement }> = ({ element }) => (
    <ul className="space-y-3 ps-5 mb-6">
        {element.items.map((item, index) => (
            <li key={index} className="flex items-start">
                <span className="text-blue-500 font-bold text-xl me-3 mt-1">{element.variant === 'check' ? '🎯' : '•'}</span>
                <span className="text-slate-700 leading-relaxed" dangerouslySetInnerHTML={{ __html: item }} />
            </li>
        ))}
    </ul>
);

const CardGrid: React.FC<{ element: CardGridElement }> = ({ element }) => {
     const variants = {
        meta: 'border-red-400',
        district: 'border-blue-500',
        school: 'border-green-500',
        management: 'border-red-400',
        training: 'border-blue-500',
        teams: 'border-green-500',
    };
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 my-8">
            {element.cards.map((card, index) => (
                <div key={index} className={`bg-white p-6 rounded-lg shadow-md border-r-4 ${variants[card.variant]}`}>
                    <h4 className="text-lg font-bold text-slate-800 mb-3" dangerouslySetInnerHTML={{ __html: card.title }} />
                    <div className="space-y-2 text-slate-600 text-sm" dangerouslySetInnerHTML={{ __html: card.items.map(i => `<p>${i}</p>`).join('') }} />
                </div>
            ))}
        </div>
    );
};

const GanttChart: React.FC<{ element: GanttChartElement }> = ({ element }) => {
    const statusClasses: {[key: string]: string} = {
        'הושלם': 'bg-green-500', 'בתהליך': 'bg-blue-500', 'מתוכנן': 'bg-slate-500', 'קריטי': 'bg-red-500'
    };
    let lastGroup = "";
    return (
        <div className="overflow-x-auto my-8">
            <table className="w-full border-collapse text-xs sm:text-sm">
                <thead>
                    <tr className="bg-slate-800 text-white">
                        {element.headers.map((h, i) => <th key={i} className="p-3 text-right border border-slate-600">{h}</th>)}
                    </tr>
                </thead>
                <tbody>
                    {element.rows.map((row, rIndex) => {
                        const showGroup = row.group && row.group !== lastGroup;
                        if(showGroup) lastGroup = row.group;
                        return (
                            <React.Fragment key={rIndex}>
                                {showGroup && (
                                    <tr className={row.variant}>
                                        <td colSpan={element.headers.length} className="p-3 font-bold text-center text-slate-800" dangerouslySetInnerHTML={{ __html: row.group || '' }}/>
                                    </tr>
                                )}
                                <tr className={`${row.variant || 'bg-white'} even:bg-slate-50`}>
                                    {row.group ? (
                                         <td className="p-3 border border-slate-200 font-semibold border-r-8" dangerouslySetInnerHTML={{__html: row.task}}/>
                                    ) : (
                                         <td className="p-3 border border-slate-200 font-semibold border-r-8" dangerouslySetInnerHTML={{__html: `<span class="ps-4">${row.task}</span>`}}/>
                                    )}
                                    <td className="p-3 border border-slate-200" dangerouslySetInnerHTML={{__html: row.responsible}}/>
                                    {element.headers.includes("שותפים") && <td className="p-3 border border-slate-200" dangerouslySetInnerHTML={{__html: row.partners || ''}}/>}
                                    {element.headers.includes("תוצרים/מטרות") && <td className="p-3 border border-slate-200" dangerouslySetInnerHTML={{__html: row.deliverable || ''}}/>}
                                    {element.headers.includes("סטטוס") && (
                                        <td className="p-3 border border-slate-200 text-center">
                                            {row.status && <span className={`text-white text-xs font-bold py-1 px-3 rounded-full ${statusClasses[row.status]}`}>{row.status}</span>}
                                        </td>
                                    )}
                                    {element.headers.slice(-7).map(month => (
                                        <td key={month} className="p-3 border border-slate-200 text-center">
                                            {row.months.includes(month) && <div className="w-full h-4 bg-blue-400 rounded-full" />}
                                        </td>
                                    ))}
                                </tr>
                            </React.Fragment>
                        )
                    })}
                </tbody>
            </table>
        </div>
    )
}


const renderElement = (element: ContentElement, isEditing: boolean, onChange: (id: string, newElement: Partial<ContentElement>) => void) => {
    switch (element.type) {
        case 'heading': return <Editable value={element.text} onChange={newText => onChange(element.id, { text: newText })} isEditing={isEditing} renderView={text => <Heading element={{...element, text}} />} renderEdit={(value, handleChange) => <div><h4 className="font-bold text-sm text-slate-400 mb-1">Heading {element.level}</h4><EditableTextArea value={value} onChange={handleChange} /></div>} />;
        case 'highlightBox': return <Editable value={element.text} onChange={newText => onChange(element.id, { text: newText })} isEditing={isEditing} renderView={text => <HighlightBox element={{...element, text}} />} renderEdit={(value, handleChange) => <div><h4 className="font-bold text-sm text-slate-400 mb-1">Highlight Box</h4><EditableTextArea value={value} onChange={handleChange} /></div>} />;
        case 'paragraph': return <Editable value={element.text} onChange={newText => onChange(element.id, { text: newText })} isEditing={isEditing} renderView={text => <Paragraph element={{...element, text}} />} renderEdit={(value, handleChange) => <div><h4 className="font-bold text-sm text-slate-400 mb-1">Paragraph</h4><EditableTextArea value={value} onChange={handleChange} /></div>} />;
        case 'list': return <Editable value={element.items} onChange={newItems => onChange(element.id, { items: newItems })} isEditing={isEditing} renderView={items => <List element={{...element, items}} />} renderEdit={(value, handleChange) => <div><h4 className="font-bold text-sm text-slate-400 mb-1">List</h4><EditableTextArea value={value.join('\n')} onChange={newText => handleChange(newText.split('\n'))} /></div>} />;
        case 'table': return <EditableTable value={element} onChange={newTable => onChange(element.id, newTable)} isEditing={isEditing} />;
        case 'cardGrid': return <CardGrid element={element} />; // Not making cards editable for simplicity
        case 'ganttChart': return <GanttChart element={element} />; // Not making gantt editable for simplicity
        default: return null;
    }
}

// --- SLIDE COMPONENT ---

interface SlideProps {
    slideData: SlideData;
    onUpdate: (updatedSlideData: SlideData) => void;
}

export const Slide: React.FC<SlideProps> = ({ slideData, onUpdate }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [localData, setLocalData] = useState<SlideData>(slideData);

    const handleEditToggle = () => {
        if (isEditing) {
            // Cancel changes
            setLocalData(slideData);
        }
        setIsEditing(!isEditing);
    };

    const handleSave = () => {
        onUpdate(localData);
        setIsEditing(false);
    };

    const handleElementChange = useCallback((id: string, newElementData: Partial<ContentElement>) => {
        setLocalData(prevData => {
            const newElements = prevData.elements.map(el =>
                el.id === id ? { ...el, ...newElementData } : el
            );
            return { ...prevData, elements: newElements };
        });
    }, []);

    return (
        <div className="relative animate-fadeIn">
            <div className="absolute top-0 left-0 flex gap-2">
                {isEditing ? (
                    <>
                        <button onClick={handleSave} className="flex items-center gap-2 bg-green-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-green-600 transition-all">
                            <SaveIcon /> שמור שינויים
                        </button>
                        <button onClick={handleEditToggle} className="flex items-center gap-2 bg-gray-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-gray-600 transition-all">
                            <CancelIcon /> בטל
                        </button>
                    </>
                ) : (
                    <button onClick={handleEditToggle} className="flex items-center gap-2 bg-blue-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-600 transition-all">
                        <EditIcon /> ערוך שקף
                    </button>
                )}
            </div>
            
            <div className="pt-16 space-y-6">
                {localData.elements.map((element) => (
                    <div key={element.id} className={`${isEditing ? 'p-4 bg-blue-50/50 border-2 border-dashed border-blue-200 rounded-lg' : ''}`}>
                         {renderElement(element, isEditing, handleElementChange)}
                    </div>
                ))}
            </div>
             <style>{`.animate-fadeIn { animation: fadeIn 0.6s ease-in-out; } @keyframes fadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }`}</style>
        </div>
    );
};
